/*Kartero App Configuration*/
var krms_driver_config ={	
	'ApiUrl':"https://tuboxv1.tupedido.app/api",
	'DialogDefaultTitle':"TuBoxv1",
	'APIHasKey':"KeyColombia2019**",
	'debug': false
};